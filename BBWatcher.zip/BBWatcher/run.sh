#!/bin/bash

toilet -f mono9 -F metal BBWatcher

tmux split-window -h "./scripts/bugcrowd.sh"
tmux split-window -h "./scripts/hackerone.sh"
tmux split-window -h "./scripts/intigriti.sh"
tmux split-window -h "./scripts/yeswehack.sh"

# Balance layout
tmux select-layout even-horizontal