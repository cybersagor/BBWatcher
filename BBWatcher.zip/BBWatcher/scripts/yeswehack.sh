#!/bin/bash

# =================================================
# CONFIGURATION
# =================================================
URL="https://raw.githubusercontent.com/arkadiyt/bounty-targets-data/refs/heads/main/data/yeswehack_data.json"
OLD_FILE="yeswehack_old_data.txt"
TMP_FILE="yeswehack_current_data.tmp"
NEW_FILE="yeswehack_new_only.tmp"
LOG_FILE="yeswehack_log.txt"

VERSION="1.0"

# =================================================
# COLORS
# =================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
GRAY='\033[0;90m'
RESET='\033[0m'
BOLD='\033[1m'
NC='\033[0m'

# =================================================
# BANNER DISPLAY
# =================================================
display_banner() {
    clear
    toilet -f mono9 -F metal YESWEHACK 2>/dev/null || \
      echo -e "${CYAN}YESWEHACK${RESET}"

    echo -e "${BLUE}${NC} ${GREEN}${BOLD}                                                       v$VERSION${NC}"
    echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC} ${GREEN}${BOLD}Powered By     ${NC}${GRAY}:${NC} Secure Startups LLC                      ${BLUE}║${NC}"
    echo -e "${BLUE}║${NC} ${GREEN}${BOLD}Version        ${NC}${GRAY}:${NC} $VERSION                                      ${BLUE}║${NC}"
    echo -e "${BLUE}║${NC} ${GREEN}${BOLD}Operator       ${NC}${GRAY}:${NC} ${CYAN}Professor the Hunter${NC}                     ${BLUE}║${NC}"
    echo -e "${BLUE}║${NC} ${GREEN}${BOLD}Timestamp      ${NC}${GRAY}:${NC} ${YELLOW}$(TZ="Asia/Dhaka" date '+%d %b %I:%M:%S %p')${NC}                       ${BLUE}║${NC}"
    echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}\n"
}

# =================================================
# FUNCTIONS
# =================================================
timestamp() {
  TZ="Asia/Dhaka" date "+${PURPLE}[%d %b %I:%M:%S %p]${RESET}"
}

timestamp_plain() {
  TZ="Asia/Dhaka" date "+%d %b %I:%M:%S %p"
}

fetch_data() {
  curl -s "$URL" | jq -r '.. | .target? // empty' | sort -u
}

# =================================================
# START
# =================================================
display_banner

if [ ! -f "$OLD_FILE" ]; then
  echo -e "$(timestamp) ${YELLOW}${BOLD}yeswehack_old_data.txt not found. Initializing...${RESET}"
  fetch_data > "$OLD_FILE"
  echo -e "$(timestamp) ${BLUE}${BOLD}Initial data saved. Monitoring started.${RESET}"
fi

touch "$LOG_FILE"

# =================================================
# MAIN LOOP
# =================================================
while true; do
  fetch_data > "$TMP_FILE"

  # Detect newly added targets
  comm -13 "$OLD_FILE" "$TMP_FILE" > "$NEW_FILE"

  if [ -s "$NEW_FILE" ]; then
    NEW_COUNT=$(wc -l < "$NEW_FILE")

    echo -e "$(timestamp) ${GREEN}${BOLD}🔥 $NEW_COUNT new target(s) added${RESET}"

    # Console output
    while read -r target; do
      echo -e "  ${CYAN}➜${RESET} ${BOLD}$target${RESET}"
    done < "$NEW_FILE"

    # Grouped logging
    {
      echo "Time: $(timestamp_plain)"
      echo "Targets:"
      i=1
      while read -r target; do
        echo "  $i. $target"
        ((i++))
      done < "$NEW_FILE"
      echo
    } >> "$LOG_FILE"

    # Notify (count only)
    echo "[$(timestamp_plain)] YesWeHack: $NEW_COUNT New Targets" \
      | notify -provider discord -id bbwatcher -silent

    # Merge and keep sorted
    cat "$OLD_FILE" "$NEW_FILE" | sort -u > "${OLD_FILE}.tmp"
    mv "${OLD_FILE}.tmp" "$OLD_FILE"
  else
    echo -e "$(timestamp) ${BLUE}🔍 Searching... No new targets found.${RESET}"
  fi

  rm -f "$TMP_FILE" "$NEW_FILE"
  sleep 60
done
